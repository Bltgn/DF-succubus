-- Succubus fortress
-- This file will run fixes and tweaks when you load your saves

-- Fix the summoned creatures skills
dfhack.run_script('fooccubus-skills')